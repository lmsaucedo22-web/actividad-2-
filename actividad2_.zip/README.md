# Actividad 2 - Notes & Categories (1:N)
Entrega lista: notas organizadas por categorías con búsqueda LIKE.

Estructura incluida:
- Category, Note, CategoryWithNotes
- NoteDao con consultas por categoría y búsqueda
- Layouts para lista de categorías y formulario de nota

Instrucciones:
1. Abrir en Android Studio.
2. Habilitar viewBinding si prefieres.
3. Compilar y ejecutar.
