package com.user.notes.data

import androidx.room.*
import com.user.notes.model.Note
import com.user.notes.model.Category
import com.user.notes.model.CategoryWithNotes

@Dao
interface NoteDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNote(note: Note): Long

    @Query("SELECT * FROM categories ORDER BY category_name")
    suspend fun getAllCategories(): List<Category>

    @Transaction
    @Query("SELECT * FROM categories ORDER BY category_name")
    suspend fun getCategoriesWithNotes(): List<CategoryWithNotes>

    @Query("SELECT * FROM notes WHERE category_id = :categoryId ORDER BY created_at DESC")
    suspend fun getNotesByCategory(categoryId: Long): List<Note>

    @Query("SELECT * FROM notes WHERE note_title LIKE '%' || :query || '%' OR note_content LIKE '%' || :query || '%' ORDER BY created_at DESC")
    suspend fun searchNotes(query: String): List<Note>

    @Query("DELETE FROM notes WHERE note_id = :id")
    suspend fun deleteNoteById(id: Long): Int
}
