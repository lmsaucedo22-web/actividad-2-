package com.user.notes.model

import androidx.room.*

@Entity(
    tableName = "notes",
    foreignKeys = [ForeignKey(entity = Category::class,
                              parentColumns = ["category_id"],
                              childColumns = ["category_id"],
                              onDelete = ForeignKey.CASCADE)],
    indices = [Index(value = ["category_id"])]
)
data class Note(
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "note_id") val noteId: Long = 0,
    @ColumnInfo(name = "note_title") val noteTitle: String,
    @ColumnInfo(name = "note_content") val noteContent: String,
    @ColumnInfo(name = "created_at") val createdAt: String,
    @ColumnInfo(name = "category_id") val categoryId: Long
)
